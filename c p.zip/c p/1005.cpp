
/*

// wap to compare two strings without using inbuilt functions 

#include <stdio.h>
#include <string.h>



int main() {
    char str1[100], str2[100];
    int i = 0, flag = 0;
    
    printf("Enter first string: ");
    gets(str1);
    
    printf("Enter second string: ");
    gets(str2);
    
    while (str1[i] != '\0' || str2[i] != '\0') {
        if (str1[i] != str2[i]) {
            flag = 1;
            break;
        }
        i++;
    }
    
    if (flag == 0) {
        printf("The strings are equal.");
    } else {
        printf("The strings are not equal.");
    }
    
    return 0;
}

*/






//wap to convert all the first character of each word in a string as capitol

// wap to for pattern matching in a string print how many times that pattern repeated in the string and also print the all the indexand highlight  

/*

#include <stdio.h>

int main() {
    char str[100];
    int i;
    int len = 0;
    
    printf("Enter a string: ");
    gets(str);
    
     while (str[len] != '\0') {
        len++;
    }
    
    
    if (str[0] >= 'a' && str[0] <= 'z') {
        str[0] -= 32;
    }
    

    for (i = 1; i < len; i++) {
        if (str[i] == ' ' && str[i+1] >= 'a' && str[i+1] <= 'z') {
            str[i+1] -= 32;
        }
    }
    
    printf("new string : %s", str);
    
    return 0;
}
*/



/*
//wap to reverse a string


#include <stdio.h>

int main() {
    char str[1000];
    int len, i, j;
    
    printf("enter the string :");
    gets(str);
    
    len = 0;
    while (str[len] != '\0') {
        len++; 
    }
    
    
    for (i = 0, j = len-1; i < j; i++, j--) {
        char temp = str[i];
        str[i] = str[j];
        str[j] = temp;
    }
    
    printf("Reversed string: %s", str);
    
    return 0;
    
    
    
    
}

*/


//wap to check palindrom or not


#include<stdio.h>
#include<string.h>

int main(){
	char str[100],temp;
	char str1[100];
	int i , j;
	print("\n enter the string :");
	gets(str);
	i=0;
	j=strlen(str)-1;
	strcpy(str1,str);
	while (i<j){
		
		temp 
	}
}







//write down a program to create a digital watch 



	
