#include<stdio.h>
int main()
{
	float x =20.20;
	void*p=&x;
	printf("%f\n",(float)*p);
	return 0;
}
