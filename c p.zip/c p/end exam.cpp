#include<stdio.h>
int main()
{
int *ptr1;
char *ptr2;
float *ptr3;
printf("\n%d",sizeof(ptr1));
printf("\n%d",sizeof(ptr2));
printf("\n%d",sizeof(ptr3));
}
