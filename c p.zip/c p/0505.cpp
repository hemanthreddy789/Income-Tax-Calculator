/*
#include<stdio.h>
int main()
 
 {
 	char name [100];
 	
 	puts ("\n Enter a string: ");
 	gets (name);
 	
 	printf("\n String is: ");
 	puts (name);
 }
 
 */
 
 
 

 
 /* 
 #include <stdio.h>
 int main()
 {
 	char name []="Klinsman";
 	int i=0;
 	while (name[i]!='\0')
 	{
 		printf("%c",name[i]);
 		i++;
 	 }
 	 
 	 printf("\n");
 	 return 0;
 }
 
 */
 
 
 
  //traversing to pointer
  
  /*
 #include <stdio.h>
 int main()
 {
 	char name[]="Klinsman";
 	char *ptr;
 	ptr= name;
 	while(*ptr!='\0')
   { 
   printf("%c",*ptr);
   ptr++;
   }
   
   printf("\n");
   return 0;
   
 
 }
 
 */
 
 
